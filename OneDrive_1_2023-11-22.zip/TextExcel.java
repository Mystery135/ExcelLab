package textExcel;
// Update this file with your own code.

public class TextExcel
{

	public static void main(String[] args)
	{
		Grid sheet = new Spreadsheet(); // Keep this as the first statement in main
		// TODO finish implementing main by adding your own code here
	}
}
